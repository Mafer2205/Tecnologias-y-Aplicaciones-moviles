package com.example.proyectotyam;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ArchivosActivity extends Activity {
    String area;
    List<Archivos> elements;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archivos);

        Intent intent = getIntent();
        if(intent == null) return;

        area = intent.getStringExtra(AreasActivity.Area);

        if (area.equals("Administrativo")) archivosAdministrativo();
        else if (area.equals("Informatica")) archivosInformatica();
        else if (area.equals("Ciencias de la Salud")) archivosSalud();
    }


    public void archivosAdministrativo() {
        elements = new ArrayList<>();
        elements.add(new Archivos("Admnistracion Financiera", "#775447"));
        elements.add(new Archivos("Conceptos Basicos de la Administracion", "#607D8B"));

        ArchivosAdapter listAdapter = new ArchivosAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }

    public void archivosInformatica() {
        elements = new ArrayList<>();
        elements.add(new Archivos("Historia de la IA", "#775447"));
        elements.add(new Archivos("Agentes en IA", "#607D8B"));

        ArchivosAdapter listAdapter = new ArchivosAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }

    public void archivosSalud() {
        elements = new ArrayList<>();
        elements.add(new Archivos("Aprendiendo del Microscopio", "#775447"));

        ArchivosAdapter listAdapter = new ArchivosAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }
}
