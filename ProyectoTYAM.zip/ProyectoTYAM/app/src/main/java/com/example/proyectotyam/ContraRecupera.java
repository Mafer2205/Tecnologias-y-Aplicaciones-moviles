package com.example.proyectotyam;

import static java.lang.Integer.parseInt;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ContraRecupera extends AppCompatActivity {

    EditText cor, contr;
    Button aceptar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recupera_contra);

        cor = (EditText) findViewById(R.id.edtCeloCorr);
        contr = (EditText) findViewById(R.id.edtNuevaContra);
        aceptar = (Button) findViewById(R.id.btnAceptar);
        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actualizaC(v);
            }
        });

    }

    public void actualizaC (View view){
        TuttorDatabase TDB = new TuttorDatabase(this);
        SQLiteDatabase bd = TDB.getWritableDatabase();

        String correo = cor.getText().toString();
        String contra  = contr.getText().toString();


        if(!correo.isEmpty() && !contra.isEmpty()){
            ContentValues regist = new ContentValues();
            regist.put("correo",correo);
            regist.put("contrasena",contra);
            String where = "correo"+ "=" + correo;

            int c = bd.update("Usuarios", regist, where, null);
            bd.close();

            if(c ==1){
                cor.setText("");
                contr.setText("");
                Toast.makeText(this, "La contraseña se actualizo de forma correcta", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this, "Correo no encontrado", Toast.LENGTH_LONG).show();
            }

        }else{
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_LONG).show();

        }
    }
}
