package com.example.proyectotyam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class InicioSesion extends AppCompatActivity {
    private EditText edCorreo, edContrasena;
    private Button is,olvido;
    private TextView  huella;
    public static final String Correo = "correo";
    public static final String Contrasena = "contrasena";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);

        edCorreo = (EditText) findViewById(R.id.edtCeloCor);
        edContrasena = (EditText) findViewById(R.id.edtContra);
        is =(Button) findViewById(R.id.btnInicioSes);
        huella =(TextView) findViewById(R.id.TVHuella);
        olvido =(Button) findViewById(R.id.TVOlvido);
        olvido.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(InicioSesion.this,ContraRecupera.class);
                startActivity(intent);
            }
        });

    }

    public void inicioSesion (View view){
        TuttorDatabase TDB = new TuttorDatabase(this);
        SQLiteDatabase bd = TDB.getWritableDatabase();

        String correo = edCorreo.getText().toString();
        String contrasena = edContrasena.getText().toString();
        int auxiliar = 0;

        if (!correo.isEmpty() && !contrasena.isEmpty()) {
            Cursor cur = bd.rawQuery("select * from Usuarios", null);
            if (cur != null && cur.moveToFirst()) {
                do {
                    if (cur.getString(5).equals(correo) && cur.getString(6).equals(contrasena)) {
                        auxiliar = 1;
                        Toast.makeText(this, "USUARIO ENCONTRADO", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getBaseContext (), UsuarioVista.class);

                        intent.putExtra(Correo, correo);
                        intent.putExtra(Contrasena, contrasena);

                        startActivity (intent);
                    }
                }
                while (cur.moveToNext());
            }
            if (auxiliar == 0) Toast.makeText(this, "USUARIO NO ENCONTRADO", Toast.LENGTH_LONG).show();
        }
        else Toast.makeText(this, "LLENAR TODOS LOS CAMPOS", Toast.LENGTH_LONG).show();
    }
}