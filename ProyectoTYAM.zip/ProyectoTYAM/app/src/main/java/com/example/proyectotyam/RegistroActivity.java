package com.example.proyectotyam;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.MapView;

public class RegistroActivity extends AppCompatActivity {

    private EditText edcorre, edcel, ednomb, edapell, ededad, edcontra;
    //private Button btnregist;
    private MapView ubic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edcorre = (EditText) findViewById(R.id.edtCorreo);
        edcel = (EditText) findViewById(R.id.edtCel);
        ednomb = (EditText) findViewById(R.id.edtNomb);
        edapell = (EditText) findViewById(R.id.edtApp);
        ededad = (EditText) findViewById(R.id.edtEdad);
        ubic = (MapView) findViewById(R.id.mapView);
        edcontra = (EditText) findViewById(R.id.edtCont);

        //btnregist = (Button) findViewById(R.id.btnRegistro);

    }

    public void registro (View view){
        TuttorDatabase TDB = new TuttorDatabase(this);
        SQLiteDatabase bd = TDB.getWritableDatabase();

        String correo = edcorre.getText().toString();
        String celular = edcel.getText().toString();
        String nombre = ednomb.getText().toString();
        String apellido  = edapell.getText().toString();
        String edad = ededad.getText().toString();
        String ubicacion = ubic.toString();
        String contra  = edcontra.getText().toString();


        if(!correo.isEmpty() && !celular.isEmpty() && !nombre.isEmpty() && !apellido.isEmpty() && !edad.isEmpty() && !ubicacion.isEmpty() && !contra.isEmpty()){
            ContentValues regist = new ContentValues();
            regist.put("nombre",nombre);
            regist.put("apellidos", apellido);
            regist.put("edad",parseInt(edad));
            regist.put("telefono",celular);
            regist.put("correo",correo);
            regist.put("contrasena",contra);
            regist.put("ubicacion",ubicacion); //revisar

            bd.insert("Usuarios", null, regist);
            bd.close();

            edcorre.setText("");
            edcel.setText("");
            ednomb.setText("");
            edapell.setText("");
            ededad.setText("");
            edcontra.setText("");

            Toast.makeText(this, "Registro exitoso, ya puedes iniciar sesion", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_LONG).show();

        }
    }
}