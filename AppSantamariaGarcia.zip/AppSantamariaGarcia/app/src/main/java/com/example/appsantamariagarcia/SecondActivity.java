package com.example.appsantamariagarcia;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends Activity {

    TextView edtName, edtAge, edtAddress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        edtName = findViewById (R.id.welcome_1);
        edtAge = findViewById (R.id.welcome_2);
        edtAddress = findViewById (R.id.welcome_3);

        Intent intent = getIntent();
        if(intent == null) return;

        String name = intent.getStringExtra(MainActivity.NAME);
        String lastname = intent.getStringExtra(MainActivity.LASTNAME);
        String age = intent.getStringExtra(MainActivity.AGE);
        String address = intent.getStringExtra(MainActivity.ADDRESS);
        String nl = name + " " + lastname;

        edtName.setText (nl);
        edtAge.setText (age);
        edtAddress.setText (address);

    }

}