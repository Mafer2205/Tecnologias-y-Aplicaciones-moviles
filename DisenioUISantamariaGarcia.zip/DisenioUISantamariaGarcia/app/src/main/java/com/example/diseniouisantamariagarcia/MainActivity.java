package com.example.diseniouisantamariagarcia;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MainActivity extends Activity {

    EditText Enomb;
    EditText Eapel;
    EditText Eedad;
    EditText Edirec;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("Actividad","OnCreate");

        Enomb = findViewById(R.id.ENombr);
        Eapel = findViewById(R.id.EApe);
        Eedad = findViewById(R.id.EEdad);
        Edirec = findViewById(R.id.EDir);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i("Actividad","OnSaveInstanceState");

        outState.putString("nombre",Enomb.getText().toString());
        outState.putString("apellido",Eapel.getText().toString());
        outState.putString("edad",Eedad.getText().toString());
        outState.putString("direccion",Edirec.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i("Actividad","OnRestoreInstanceState");

        String name = savedInstanceState.getString("nombre");
        Enomb.setText(name);

        String lastname = savedInstanceState.getString("apellido");
        Eapel.setText(lastname);

        String age = savedInstanceState.getString("edad");
        Eedad.setText(age);

        String dir = savedInstanceState.getString("direccion");
        Edirec.setText(dir);
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.i("Actividad","OnStart");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i("Actividad","OnResume");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i("Actividad","OnPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.i("Actividad","OnStop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.i("Actividad","OnDestroy");
    }

}