package com.example.metadatos_garcia_santamaria;

import androidx.annotation.NonNull;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri; /*ESTO AGREGO GRIS*/
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View; /*AQUI*/
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class MainActivity extends Activity {

    public static final int REQUEST_CODE_EXTERNAL_STORAGE = 1001;
    public static final int REQUEST_CODE = 2001;
    private static final int PICK_IMAGE = 100; /*ESTO LO AGREGO GRIS*/
    //Uri imageUri; /*ESTO AGREGO GRIS*/
    //TextView img;
    Button cam;
    ImageView picture; /*AQUI*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        picture = findViewById(R.id.pictureGallery); /*AQUI*/

        cam = findViewById(R.id.cam);
        cam.setOnClickListener (view -> {
            Intent intent = new Intent (getBaseContext (), SecondActivity.class);
            startActivity (intent);
        });

        int perm = getBaseContext ().checkSelfPermission (Manifest.permission.READ_EXTERNAL_STORAGE);
        if (perm != PackageManager.PERMISSION_GRANTED) { requestPermissions (
                    new String [] { Manifest.permission.READ_EXTERNAL_STORAGE },
                    REQUEST_CODE_EXTERNAL_STORAGE
            );
            return;
        }
        //loadimage ();
        //openGallery();
    }

    public void onclick (View view) { /*AQUI*/
        openGallery();
    }

    private void openGallery () { /*AQUI*/
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");
        startActivityForResult(intent.createChooser(intent, "Seleccionar"),10);
    }

    /*ESTO LO AGREGO GRIS*/
    /*private void openGallery () {
        //Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        Intent gallery = new Intent( Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }*/

    @Override /*AQUI*/
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data); /*AQUI*/
        if (resultCode == RESULT_OK){
            Uri path = data.getData();
            picture.setImageURI(path);
        }
    }

    /*void loadimage () {
        String[] columns = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DISPLAY_NAME};
        String order = MediaStore.Images.Media.DEFAULT_SORT_ORDER;
        String selection = MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?";
        String [] selectionArgs = { "%Lake%" };

        Cursor cursor = getBaseContext ()
                .getContentResolver ()
                .query (MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, selection, selectionArgs, order);

        if (cursor == null) return;

        LinkedList<String> ph = new LinkedList<>();

        for (int i = 0; i < cursor.getCount(); i++) {
            cursor.moveToPosition(i);

            int index = cursor.getColumnIndexOrThrow (MediaStore.Images.Media.DISPLAY_NAME);
            String pho = cursor.getString (index);

            ph.add (pho);
        }

        cursor.close ();

        img = findViewById(R.id.Imagenes);
        for (String s: ph) {
            img.setText(s);
        }
    }*/

    @Override
    public void onRequestPermissionsResult (int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult (requestCode, permissions, grantResults);

        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults [0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText (getBaseContext(),"Permission Granted!", Toast.LENGTH_LONG).show ();
                }
                break;
            case REQUEST_CODE_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults [0] == PackageManager.PERMISSION_GRANTED) {
                    //loadimage ();
                }
                break;
        }
    }
}
