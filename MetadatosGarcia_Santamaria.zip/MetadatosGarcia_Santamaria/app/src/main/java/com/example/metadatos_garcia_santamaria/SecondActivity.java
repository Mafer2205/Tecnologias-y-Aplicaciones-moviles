package com.example.metadatos_garcia_santamaria;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SecondActivity extends Activity {
    LocationListener locationListener;
    LocationManager locationManager;
    public static final int REQUEST_CODE_CAMERA = 1;
    ImageView picture;
    Button btnfoto;
    String currentPhotoPath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        picture = findViewById (R.id.picture);
        btnfoto = findViewById(R.id.btnfoto);

        btnfoto.setOnClickListener(view ->{
            int p = checkSelfPermission(Manifest.permission.CAMERA);
            if(p != PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[] {Manifest.permission.CAMERA},
                        REQUEST_CODE_CAMERA);
                return;
            }
            doPhoto();

        });
    }

    private void doPhoto (){
        Intent takepicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takepicture.resolveActivity(getPackageManager()) != null){

            File im = null;
            try{
                im = createImageFile();
            } catch (IOException ex){
                Log.e("Error",ex.toString());
            }

            if(im != null){
                Uri fotouri = FileProvider.getUriForFile(this,"com.example.metadatos_garcia_santamaria.fileprovider",im);
                takepicture.putExtra(MediaStore.EXTRA_OUTPUT,fotouri);
                startActivityForResult(takepicture, REQUEST_CODE_CAMERA);
            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if (requestCode == REQUEST_CODE_CAMERA && resultCode == RESULT_OK){
            //Bundle e = data.getExtras();
            Bitmap imageb = BitmapFactory.decodeFile(currentPhotoPath);
            picture.setImageBitmap(imageb);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && requestCode == REQUEST_CODE_CAMERA) {
            if (grantResults [0] == PackageManager.PERMISSION_GRANTED) {
                doPhoto ();
            }
        }
        if (requestCode == 1001) {
            if (grantResults [0] == PackageManager.PERMISSION_GRANTED) {
                beginRequestLocation ();
            }
        }

    }

    private File createImageFile() throws IOException{
        String imageFileName = "Foto_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_DCIM);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);

        currentPhotoPath = image.getAbsolutePath();
        return image;
    }



    @Override
    protected void onResume () {
        super.onResume ();

        int permission = getBaseContext().checkSelfPermission (Manifest.permission.ACCESS_FINE_LOCATION);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            requestPermissions (
                    new String [] { Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION },
                    1001
            );

            return;
        }

        beginRequestLocation ();
    }

    @SuppressLint("MissingPermission")
    private void beginRequestLocation () {
        locationListener = new MyLocationListener ();
        locationManager = (LocationManager) getSystemService (LOCATION_SERVICE);
        locationManager.requestLocationUpdates (LocationManager.GPS_PROVIDER,
                5000,
                10,
                locationListener);
    }

    @Override
    protected void onPause () {
        super.onPause ();
        locationManager.removeUpdates (locationListener);
    }


    class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(@NonNull Location location) {
            Toast.makeText (getBaseContext (),
                    "LocatinChanged: Lat " + location.getLatitude() + " Log: " + location.getLongitude (),
                    Toast.LENGTH_LONG).show ();

            Geocoder geocoder = new Geocoder (getBaseContext(), Locale.getDefault ());
            List<Address> addresses;
            String city = "";

            try {
                addresses = geocoder.getFromLocation (location.getLatitude(), location.getLongitude(), 1);
                if (addresses.size () > 0) {
                    //Log.i ("GEO", addresses.get (0).getLocality ());

                    city = addresses.get (0).getLocality ();
                }
            } catch (IOException ex) {
                ex.printStackTrace ();
            }

            Log.i ("GEO", "City found: " + city);
        }


        public void onLocationChanged(@NonNull List<Location> locations) {

        }


        public void onFlushComplete(int requestCode) {

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(@NonNull String provider) {

        }

        @Override
        public void onProviderDisabled(@NonNull String provider) {

        }
    }
}